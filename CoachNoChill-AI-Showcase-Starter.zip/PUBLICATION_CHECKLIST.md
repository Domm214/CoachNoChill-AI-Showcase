# Publication checklist

- [ ] Create a **new, empty public** repository named `CoachNoChill-AI-Showcase` (do not change the private application's visibility).
- [ ] Upload only the files from this showcase package.
- [ ] Confirm no production code, databases, secrets, ZIP archives, or logs are included.
- [ ] Review the full content of README and docs for private or inaccurate details.
- [ ] Confirm the SVG architecture diagram renders in the GitHub README.
- [ ] Add real, **redacted** screenshots later; keep members' privacy in mind.
- [ ] Add the public repository URL to LinkedIn **Projects** and **Featured**.
- [ ] Review the page anonymously/incognito to ensure recruiters can see it without signing in.

**Suggested repo description:** AI-powered Discord assistant and cloud automation case study built with Python, OpenAI API, SQLite, Docker, and Railway.

**Topics:** `python` `ai` `discord-bot` `automation` `cloud` `docker` `railway` `sqlite` `portfolio` `devops`

**Important:** This is a portfolio showcase, not an open-source release of the production application. Don't paste credentials or a copy of the private repository into this public repository.
