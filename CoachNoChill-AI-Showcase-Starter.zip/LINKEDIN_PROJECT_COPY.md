# LinkedIn project entry

**Project name:** CoachNoChill AI | AI-Powered Discord Automation Platform

**Project URL:** Add the URL of the **new public showcase repository** after it is created.

**Short summary:** Built and maintain a live Python-based Discord AI assistant and cloud automation platform supporting an online 32-team franchise league. Integrated OpenAI and league-data APIs, SQLite persistence, scheduling and awards workflows, role-based approvals, and deployment/testing processes using Docker, Railway and GitHub Actions. Extended the architecture toward multi-server Hosted Edition capabilities with privacy and tenant-isolation controls.

**Skills:** Python · Artificial Intelligence (AI) · API Integration · Cloud Computing · Software Development

**Post caption idea:**

I built CoachNoChill AI to solve a real operational problem: keeping a 32-team online franchise league organized without doing every repetitive task manually. What started as a Discord assistant has evolved into a cloud-hosted Python platform with conversational AI, API integrations, persistent state, automated scheduling and awards, and commissioner approval workflows.

The biggest lessons weren't just coding. They were handling changing requirements, keeping live data accurate, troubleshooting cloud deployments, and designing reliable software that real people use.

I put together a public technical showcase with an architecture overview and engineering case study (the production code stays private). [Insert showcase URL]

#Python #ArtificialIntelligence #CloudComputing #SoftwareDevelopment #DevOps
