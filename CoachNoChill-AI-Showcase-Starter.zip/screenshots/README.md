# Screenshot plan (real images only)

No synthetic images should be presented as evidence of a working product. Add authentic Discord, GitHub Actions, or Railway captures only after reviewing sensitive information and obtaining permission where appropriate.

Recommended captures:

1. **assistant-answer.png** — A question and a grounded response (use your own test account; hide member names and IDs).
2. **commissioner-dashboard.png** — Dashboard, advance countdown, or matchup status (hide private channels/owner IDs).
3. **weekly-awards.png** — POTW or GOTW publishing workflow for a test or public-safe example.
4. **release-checks.png** — Successful validation/deployment checks (remove environment details, tokens, service URLs, account identifiers).

Suggested editing: crop to the relevant interaction, obscure names and identifiers, and keep readable text. Never paste tokens into a screenshot. Review file names and metadata too.

After the images are ready, update `README.md` to include:

```markdown
## Product in action

![CoachNoChill AI answering a league question](screenshots/assistant-answer.png)
![Commissioner dashboard](screenshots/commissioner-dashboard.png)
![Weekly awards workflow](screenshots/weekly-awards.png)
```

If screenshots cannot be shared safely, use a short recording of a test server or skip the gallery. The architecture diagram already provides a useful visual.
