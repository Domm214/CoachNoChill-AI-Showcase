# Architecture and design boundaries

This document describes the major concepts in CoachNoChill AI. It is an **architectural overview**, not a full source inventory, deployment recipe, or a claim that every optional feature is enabled in production.

![High-level architecture](../assets/architecture.svg)

## Interaction layer

League owners, members, and commissioners interact through Discord commands, buttons, message-based questions, and gated workflows. The application validates the server/user context and distinguishes read-only assistance from operations requiring human approval.

## Two separate runtime paths

| Runtime | Purpose | Boundary |
|---|---|---|
| Single-league runtime | Madden league automation, schedules, awards, commissioner assistance | Dedicated league configuration and SQLite data for that deployment |
| Hosted Edition runtime | Multi-server assistant experience, approved Server Brain knowledge, missions, skills and usage tracking | Separate startup path and guild-scoped persistence; capabilities gated by permissions and opt-in flags |

The two paths share engineering ideas and a private codebase but should **not** be presented as one unrestricted, globally shared production bot. The Hosted Edition was designed to prevent one Discord server from accessing another server's data.

## Services and data flow

1. A Discord member requests assistance.
2. Python/`discord.py` routes the request through permission and context checks.
3. Structured league questions use verified data and deterministic logic when possible.
4. Supported AI questions use approved context with the OpenAI API. The answer separates verified facts from advice or uncertainty.
5. Where permitted, the runtime records limited operational state and receipts in the relevant SQLite database.
6. Any protected administrative action requires the authorized human review path.

**External integration:** The single-league experience may obtain read-only schedules, player and team information, and results from the NeonSportz/Madden feed. This is not permission to update Madden data or make official commissioner rulings.

## Delivery and operations

- GitHub branches and pull requests manage changes to the private source repository.
- GitHub Actions and test suites support compilation, regressions, and safe changes.
- Docker packages the Python application and dependencies.
- Railway hosts application runtimes and supports persistent storage.
- Startup integrity checks, backups/restore validation, error handling, and health diagnostics support reliability.

## Important limits

- Optional capabilities require configuration, permissions, and sometimes external services; they should not be described as universally active.
- API/model outputs are not guaranteed to be correct. The platform uses approved context and review boundaries rather than relying on AI alone.
- This portfolio intentionally omits secrets, private IDs, production database tables and full code.
