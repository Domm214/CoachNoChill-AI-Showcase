# Security and privacy of this public showcase

This repository contains **documentation and public-safe diagrams**, not the production bot, its secrets, or private league records.

## Intentional exclusions

- Discord bot tokens, OpenAI API keys, Railway environment variables and provider secrets
- Discord server/member IDs and private messages
- Runtime SQLite databases, backups, operational logs and session transcripts
- Production configuration, private endpoints, webhooks and sensitive implementation details
- Third-party user information or screenshots without appropriate redaction/permission

## Controls in the private application

The private platform uses permission boundaries, commissioner approval workflows, tenant-scoped Hosted Edition data, explicit knowledge ingestion controls, and integrity checks/backup strategies. The presence of these patterns should not be interpreted as a security certification or a guarantee of freedom from vulnerabilities.

## Reporting an issue

Please do not publish possible secrets or personal information in a public issue. Contact the project owner privately through LinkedIn.

## Before public release

Check all files and **Git history** for secrets and personal data, verify image metadata, and ensure no production credentials are included. Changing a GitHub repository from private to public exposes its prior commit history; that is why this showcase is built as a **new repository**, never by changing the production repository's visibility.
